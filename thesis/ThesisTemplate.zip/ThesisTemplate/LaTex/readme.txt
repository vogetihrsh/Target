
To make a sample thesis, copy the contents of this directory
somewhere, and type the following commands

 latex sampleThesis
 bibtex sampleBib
 latex sampleThesis